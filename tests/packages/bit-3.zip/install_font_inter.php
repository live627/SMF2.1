<?php
/**
 *
 * @package Font Inter for SMF 2.1
 * @author wintstar - www.stephan-frank.de
 * @copyright 2021 SF Webdesign
 * @license http://opensource.org/licenses/gpl-2.0.php GPL-2.0
 *
 * @version 1.1
 */

/**
 *	This script prepares database changes that the mod Font Inter requires.
 *
 *	NOTE: This script is meant to run using the <samp><database></database></samp> elements of the package-info.xml file. This is so
 *	that admins have the choice to uninstall any database data installed with the mod. Also, since using the <samp><database></samp>
 *	elements automatically calls on db_extend('packages'), we will only be calling that if we are running this script standalone.
 *
 * many thanks to Simple Desk Project - www.simpledesk.net, for this install script
 *
 *	@package install
 *	@since 1.0
 */

/**
 *	Before attempting to execute, this file attempts to load SSI.php to enable access to the database functions.
*/
font_inter_initialize_install();

// Install options
font_inter_get_install_settings();

// Are we done?
if (SMF == 'SSI')
	echo 'Database changes are complete!';

/**
 * Sets up the installer
 *
 * font_inter_initialize_install
 *
 * @return void
 */
function font_inter_initialize_install()
{
	// If we have found SSI.php and we are outside of SMF, then we are running standalone.
	if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
		require_once(dirname(__FILE__) . '/SSI.php');
	elseif (file_exists(getcwd() . '/SSI.php') && !defined('SMF'))
		require_once(getcwd() . '/SSI.php');
	elseif (!defined('SMF')) // If we are outside SMF and can't find SSI.php, then throw an error
		die('<b>Error:</b> Cannot install - please verify you put this file in the same place as SMF\'s SSI.php.');

	if (SMF == 'SSI')
		db_extend('packages');

	// We have a lot to do. Make sure as best we can that we have the time to do so. But only if the function wasn't disabled.
	if (function_exists('set_time_limit'))
		set_time_limit(600);
}

function font_inter_get_install_settings()
{
	global $smcFunc;

	$insertValues[] = array(1, 0, 'inter_font_enable', 1);
	$insertValues[] = array(1, 0, 'inter_fontsize_settings', 'large');
	$insertValues[] = array(1, 1, 'inter_fontsize_options', 'default');

	$smcFunc['db_insert']('replace',
		'{db_prefix}themes',
		array('id_theme' => 'int', 'id_member' => 'int', 'variable' => 'string-255', 'value' => 'string-65534'),
		$insertValues,
		array('id_theme', 'variable', 'id_member')
	);
}

?>