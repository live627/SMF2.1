<?php
/**
 *
 * @package Font Inter for SMF 2.1
 * @author wintstar - www.stephan-frank.de
 * @copyright 2021 SF Webdesign
 * @license http://opensource.org/licenses/gpl-2.0.php GPL-2.0
 *
 * @version 1.1
 */

/**
 *	This script removes all the extraneous data if the user requests it be removed on uninstall.
 *
 *	NOTE: This script is meant to run using the <samp><code></code></samp> elements of our package-info.xml file. This is because
 *	certain items in the database and within SMF will need to be removed regardless of whether the user wants to keep data or not,
 *	for example DB-Backup needs to be deactivated in the Core Features panel, which must be done regardless of whether the user
 *	wanted to keep data or not during uninstallation. Future expansions may add items here, especially such as background tasks.
 *
 * many thanks to Simple Desk Project - www.simpledesk.net, for this install script
 *
 *	@package installer
 *	@since 1.0
 */

/**
 *	Before attempting to execute, this file attempts to load SSI.php to enable access to the database functions.
*/

// If we have found SSI.php and we are outside of SMF, then we are running standalone.
if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
{
	require_once(dirname(__FILE__) . '/SSI.php');
	db_extend('packages');
}
// If we are outside SMF and can't find SSI.php, then throw an error
elseif (!defined('SMF'))
{
	die('<b>Error:</b> Cannot uninstall - please verify you put this file in the same place as SMF\'s SSI.php.');
}

global $modSettings, $smcFunc;

$smcFunc['db_query']('', '
	DELETE FROM {db_prefix}themes
	WHERE variable IN ({string:font_enable}, {string:fontsize_settings}, {string:fontsize_options})',
	array(
		'font_enable' => 'inter_font_enable',
		'fontsize_settings' => 'inter_fontsize_settings',
		'fontsize_options' => 'inter_fontsize_options',
	)
);

if (!empty($modSettings['minimize_files']) || !isset($modSettings['minimize_files']))
	deleteAllMinified();

?>