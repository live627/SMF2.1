[size=5][b]SF Webdesign[/b][/size]
[url]http://www.stephan-frank.de[/url]

[size=4][b]Font Inter for SMF[/b][/size]
[i]Version 1.1[/i]

Added the [url=https://rsms.me/inter/]Webfont Inter v3.19[/url] in your Theme.

Inter is a typeface carefully crafted & designed for computer screens.
Inter features a tall x-height to aid in readability of mixed-case and lower-case text. Several OpenType features are provided as well,
like contextual alternates that adjusts punctuation depending on the shape of surrounding glyphs, slashed zero for when you need
to disambiguate "0" from "o", tabular numbers, etc.

Features
[list]
[li]Font Inter can be disabled and the font size can be set in the Admin Center[/li]
[li]Font size of the members can be reset in the Admin Center[/li]
[li]Members can select the font size in their profile if the Inter font is enabled[/li]
[/list]

[b][size=12pt]SF Webdesign[/size][/b]
»Web Design, Anwendungen und Styles für Foren«