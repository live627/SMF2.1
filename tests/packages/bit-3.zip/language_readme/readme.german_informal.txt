﻿[size=5][b]SF Webdesign[/b][/size]
[url]http://www.stephan-frank.de[/url]

[size=4][b]Font Inter for SMF[/b][/size]
[i]Version 1.1[/i]

Fügt die [url=https://rsms.me/inter/]Schriftart Inter v3.19[/url] in ihr Theme.

Inter ist eine Schrift, die sorgfältig für Computerbildschirme entworfen und gestaltet wurde.
Inter verfügt über eine hohe x-Höhe, um die Lesbarkeit von Text in Groß- und Kleinbuchstaben zu verbessern. Mehrere OpenType-Funktionen sind ebenfalls vorhanden,
wie z. B. kontextabhängige Alternativen, die die Interpunktion je nach Form der umgebenden Glyphen anpassen, sowie die geschlitzte Null, wenn Sie
0" von "o" zu unterscheiden ist, Tabellennummern, usw.

Funktionen
[list]
[li]Schriftart Inter kann im Admin Center deaktiviert und die Schriftgröße festgelegt werden[/li]
[li]Schriftgröße der Mitglieder kann im Admin Center zurück gesetzt werden[/li]
[li]Mitglieder können die Schriftgröße in ihrem Profil auswählen, wenn die Schriftart Inter aktiviert ist[/li]
[/list]

[b][size=12pt]SF Webdesign[/size][/b]
»Web Design, Anwendungen und Styles für Foren«