<?php
/**
 * www.stephan-frank.de
 *
 * @package SF - Page Mod for MCS
 * @author Franky
 * @copyright 2020 SF Webdesign
 * @license http://opensource.org/licenses/gpl-2.0.php GPL-2.0
 *
 * @version 1.0.0
 */

define('FONT_INTER_VERSION', '1.1');

// First of all, we make sure we are accessing the source file via MCS so that people can not directly access the file.
if (!defined('SMF'))
	die('Hack Attempt...');


/**
 * font_inter_integrate_load_theme
 *
 * @return void
 */
function font_inter_load_theme()
{
	global $context, $settings, $options, $modSettings;

	$inter_fontsize = $context['user']['is_guest'] ? $settings['inter_fontsize_settings'] : (($options['inter_fontsize_options'] == 'default') ? $settings['inter_fontsize_settings'] : $options['inter_fontsize_options']);

	if (!empty($settings['inter_font_enable']))
		loadCSSFile('font_inter_css/font-inter-' . $inter_fontsize . '.css', array('minimize' => true, 'order_pos' => 2), 'font-inter');
}

function font_inter_theme_settings()
{
	global $context, $modSettings, $txt;

	loadlanguage('font_inter_language/FontInter');

	$font_inter_settings = array(
		'',
		array(
			'id' => 'inter_font_enable',
			'label' => $txt['font_inter_enable'],
			'description' => $txt['font_inter_info'],
		),
		array(
			'id' => 'inter_fontsize_settings',
			'label' => $txt['font_inter_fontsize'],
			'options' => array(
				'small' => $txt['font_inter_small'],
				'medium' => $txt['font_inter_medium'],
				'large' => $txt['font_inter_large'],
				'larger' => $txt['font_inter_larger'],
			),
			'type' => 'list',
		)
	);

	$context['theme_settings'] = array_merge($context['theme_settings'], $font_inter_settings);

	if (!empty($modSettings['minimize_files']) || !isset($modSettings['minimize_files']))
		deleteAllMinified();
}

function font_inter_theme_options()
{
	global $context, $modSettings, $settings, $txt;

	loadlanguage('font_inter_language/FontInter');

	// Add the settings to the default theme's settings page (Curve2)
	$font_inter_options = array(
		$txt['font_inter_title'],
		array(
			'id' => 'inter_fontsize_options',
			'label' => $txt['font_inter_fontsize'],
			'options' => array(
				'default' => $txt['font_inter_default'],
				'small' => $txt['font_inter_small'],
				'medium' => $txt['font_inter_medium'],
				'large' => $txt['font_inter_large'],
				'larger' => $txt['font_inter_larger'],
			),
			'default' => true,
			'enabled' => !empty($settings['inter_font_enable']),
		)
	);

	$context['theme_options'] = array_merge($context['theme_options'], $font_inter_options);

	if (!empty($modSettings['minimize_files']) || !isset($modSettings['minimize_files']))
		deleteAllMinified();
}

/**
 * font_inter_credits
 *
 * @return void
 */
function font_inter_credits()
{
	global $context;

	$context['credits_modifications'][] = 'Font Inter ' . FONT_INTER_VERSION . ' © ' . SMF_SOFTWARE_YEAR . ',
	<a href="https://www.stephan-frank.de" title="SF Webdesign" target="_blank" rel="noopener">SF Webdesign</a>';
}

?>