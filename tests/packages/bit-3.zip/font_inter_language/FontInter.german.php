<?php

// Version 1.1; Font Inter

// Admin
$txt['font_inter_title']		= 'Schriftart Inter';
$txt['font_inter_enable']		= 'Schriftart Inter aktivieren';
$txt['font_inter_info']			= '<a href="https://rsms.me/inter/" target="_blank" rel="noopener">Schriftart Inter</a> ist eine Schrift, die sorgfältig für Computerbildschirme entworfen und gestaltet wurde.';
$txt['font_inter_fontsize'] 	= 'Schriftgröße Inter';
$txt['font_inter_small'] 		= 'Klein';
$txt['font_inter_medium'] 		= 'Mittel';
$txt['font_inter_large'] 		= 'Groß';
$txt['font_inter_larger'] 		= 'Größer';
$txt['font_inter_default']      = 'Forum Standard';

?>