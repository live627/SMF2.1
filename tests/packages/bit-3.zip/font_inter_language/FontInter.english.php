<?php

// Version 1.1; Font Inter

// Admin
$txt['font_inter_title']		= 'Font Inter';
$txt['font_inter_enable']		= 'Enable Font Inter';
$txt['font_inter_info']			= '<a href="https://rsms.me/inter/" target="_blank" rel="noopener">Font Inter</a> is a typeface carefully crafted & designed for computer screens.';
$txt['font_inter_fontsize'] 	= 'Font size Inter';
$txt['font_inter_small'] 		= 'Small';
$txt['font_inter_medium'] 		= 'Medium';
$txt['font_inter_large'] 		= 'Large';
$txt['font_inter_larger'] 		= 'Larger';
$txt['font_inter_default']      = 'Forum default';

?>